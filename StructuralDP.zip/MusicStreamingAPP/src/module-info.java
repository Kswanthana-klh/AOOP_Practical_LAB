/**
 * 
 */
/**
 * 
 */
module MusicStreamingAPP {
}